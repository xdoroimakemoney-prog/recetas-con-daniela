# Recetas con Daniela

Sitio en español mexicano para los materiales educativos de Daniela Martínez González.

## Contenido

- `index.html`: sitio mobile-first con vídeos, preguntas frecuentes y contribuciones.
- `assets/`: imágenes, portadas reales de los ocho PDF y miniaturas de vídeos.
- Los PDF se consultan en Google Drive; el sitio no incluye copias de los documentos.

## Publicación

Este es un sitio estático, sin proceso de compilación.

### Cloudflare Pages

Conecta este repositorio a **Workers & Pages → Pages**. Selecciona el repositorio y despliega sin comando de compilación (directorio de salida: `/` o la raíz del proyecto, según la interfaz). Confirma el dominio `*.pages.dev` resultante.

### Vercel

Importa este repositorio en la Vercel, con framework `Other` y sin comando de compilación. **Nota:** los proyectos comerciales requieren un plan que permita uso comercial; el plan Hobby está limitado a uso personal no comercial.

## Revisión previa al lanzamiento

- Verifica que los lectores de los ocho PDF se puedan abrir públicamente.
- Prueba la reproducción de vídeos: la disponibilidad depende de las políticas de incrustación de cada canal de YouTube.
- Comprueba los datos de pago y el acceso al grupo de WhatsApp.
- Comprueba que los materiales con contenido sobre diabetes tengan revisión profesional.
